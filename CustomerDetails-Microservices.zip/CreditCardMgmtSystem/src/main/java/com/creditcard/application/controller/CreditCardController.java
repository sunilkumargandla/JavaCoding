package com.creditcard.application.controller;

import java.net.URISyntaxException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.creditcard.application.model.Customer;
import com.creditcard.application.service.CreditCardService;

@RestController
@RefreshScope
public class CreditCardController {

	@Autowired
	CreditCardService service;

	@RequestMapping(value = "/creditcard", method = RequestMethod.POST)
	public ResponseEntity<String> creditCardEligibility(@RequestBody Customer customerDetails) {
		ResponseEntity<String> result = null;
		try {
			result = service.validateCustomer(customerDetails);
		} catch (URISyntaxException e) {
			e.getMessage();
		}
		return result;
	}
}
