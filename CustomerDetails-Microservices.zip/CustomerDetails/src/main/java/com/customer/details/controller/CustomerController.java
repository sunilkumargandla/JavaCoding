package com.customer.details.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.customer.details.service.CustomerService;
import org.springframework.http.HttpStatus;

@RestController
public class CustomerController {

	@Autowired
	CustomerService service;

	@RequestMapping(value = "/creditCardEligibility/{id}", method = RequestMethod.GET)
	public ResponseEntity<String> custEligibilityForCreditCard(@PathVariable  int id) {
		String result = service.getCustomerdetails(id);
		return new ResponseEntity<String>(result, HttpStatus.OK);
	}

}
