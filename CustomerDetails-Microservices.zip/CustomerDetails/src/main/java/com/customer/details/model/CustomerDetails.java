package com.customer.details.model;

public class CustomerDetails {

	int sal;
	boolean loan;
	int emi;

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	/*
	 * public int getId() { return id; } public void setId(int id) { this.id = id; }
	 */
	public boolean isLoan() {
		return loan;
	}

	public void setLoan(boolean loan) {
		this.loan = loan;
	}

	public int getEmi() {
		return emi;
	}

	public void setEmi(int emi) {
		this.emi = emi;
	}

}
