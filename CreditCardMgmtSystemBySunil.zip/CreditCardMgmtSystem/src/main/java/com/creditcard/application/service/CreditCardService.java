package com.creditcard.application.service;

import java.net.URISyntaxException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;

import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.creditcard.application.model.Customer;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class CreditCardService {
	@Autowired
	RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "creditEligibility_Fallback")
	public ResponseEntity<String> validateCustomer(Customer customerDetails) throws URISyntaxException {
		if (customerDetails.getAge() > 20 && customerDetails.getAge() < 60) {
			int id = customerDetails.getId();

			String response = restTemplate.exchange("http://crediteligibilty/creditCardEligibility/{id}",
					HttpMethod.GET, null, new ParameterizedTypeReference<String>() {
					}, id).getBody();

			return new ResponseEntity<String>(response, HttpStatus.OK);

		}
		return new ResponseEntity<String>("REJECT", HttpStatus.OK);
	}

	@SuppressWarnings("unused")
	private ResponseEntity<String> creditEligibility_Fallback(Customer customerDetails) {

		System.out.println("creditEligibilty Service is down!!! fallback route enabled...");

		String fallBack = "CIRCUIT BREAKER ENABLED!!! No Response From creditEligibilty at this moment. "
				+ " Service will be back shortly - " + new Date();
		return new ResponseEntity<String>(fallBack, HttpStatus.OK);

	}

}