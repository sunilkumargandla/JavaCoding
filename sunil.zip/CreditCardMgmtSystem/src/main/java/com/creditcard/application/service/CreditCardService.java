package com.creditcard.application.service;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import com.creditcard.application.model.Customer;

@Service
public class CreditCardService {
	@Autowired
	RestTemplate restTemplate;

	public ResponseEntity<String> validateCustomer(Customer customerDetails) throws URISyntaxException {
		// TODO Auto-generated method stub
		ResponseEntity<String> result=null;
		if(customerDetails.getAge()>20 && customerDetails.getAge()<60) {
			System.out.println("call the microservice");
			String url = "http://crediteligibilty/creditCardEligibility/101";
			 //final String baseUrl = "http://localhost:"+randomServerPort+"/employees/";
			    URI uri = new URI(url);
			     
			    HttpHeaders headers = new HttpHeaders();
			    headers.set("Content-Type", "application/json");
			 
			    HttpEntity<Customer> requestEntity = new HttpEntity<>(null, headers);
			 
			    try
			    {
			       result=  restTemplate.exchange(uri, HttpMethod.GET, requestEntity, String.class);
					
					return result;
		}catch(Exception e){
			
		}
		return new ResponseEntity("REJECT",HttpStatus.OK);
	
	}
		return result;
}
}