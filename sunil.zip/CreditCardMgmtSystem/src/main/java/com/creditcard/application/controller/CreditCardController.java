package com.creditcard.application.controller;

import java.net.URISyntaxException;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.creditcard.application.model.Customer;
import com.creditcard.application.service.CreditCardService;
//import org.springframework.http.HttpStatus;

@RestController
//@RequestMapping(value = "/credit")
public class CreditCardController {

	 @Autowired
	    RestTemplate restTemplate;
	 @Autowired
	 CreditCardService service;
	 
	 @RequestMapping(value = "/gettest", method = RequestMethod.GET)
	 public ResponseEntity<String> getCreditTest( ) 
	    {
	    	String result="Test";
	    	 return new ResponseEntity<String>(result,org.springframework.http.HttpStatus.OK);
	    }
	    @RequestMapping(value = "/creditcard", method = RequestMethod.POST)
	    public ResponseEntity<String> creditCardEligibility(@RequestBody Customer customerDetails) throws URISyntaxException 
	    {
	    	ResponseEntity<String> result=service.validateCustomer(customerDetails);
	    	
	        	System.out.println("the result is::"+result);
	    	
	    	 return result;
	    }
}

	 
	 

