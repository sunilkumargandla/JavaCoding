package com.customer.details.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.customer.details.model.CustomerDetails;
import com.customer.details.service.CustomerService;

@RestController
public class CustomerController {
	
	 @Autowired
	    RestTemplate restTemplate;
	 @Autowired
	 CustomerService service;
	 
	 @RequestMapping(value = "/gettest", method = RequestMethod.POST)
	 public ResponseEntity<String> getCreditTest( ) 
	    {
	    	String result="Test";
	    	 return new ResponseEntity<String>(result,org.springframework.http.HttpStatus.OK);
	    }
	    @RequestMapping(value = "/creditCardEligibility/{id}", method = RequestMethod.POST)
	    public ResponseEntity<String> custEligibilityForCreditCard(@PathVariable int id ) 
	    {
	    	String result=service.getCustomerdetails(id);
	    	
	        	System.out.println("the result is::"+result);
	    	
	    	 return new ResponseEntity<String>(result,org.springframework.http.HttpStatus.OK);
	    }


}
