package com.customer.details.service;


import java.util.HashMap;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.customer.details.model.CustomerDetails;

@Service
public class CustomerService {
	
	private static Map<Integer,CustomerDetails> customerDetails = new HashMap<Integer, CustomerDetails>();
	 
    static {
    	CustomerDetails details1= new  CustomerDetails();
    	details1.setSal(100000);
    	details1.setLoan(true);
    	details1.setEmi(5000);
    	CustomerDetails details2= new  CustomerDetails();
    	details2.setSal(10000);
    	details2.setLoan(true);
    	details2.setEmi(5000);
    	CustomerDetails details3= new  CustomerDetails();
    	details3.setSal(200000);
    	details3.setLoan(false);
    	//details3.setEmi();
    	customerDetails.put(101,details1) ;
    	customerDetails.put(201,details2) ;
    	customerDetails.put(301,details3) ;
    }

	public String getCustomerdetails(int id) {
	
	CustomerDetails custDetails=	customerDetails.get(id);
  
	  if(custDetails.getSal()>=50000) {
		  if(!custDetails.isLoan()) {
			  return "SELECT";
		  }
		  else {
			  if(custDetails.getEmi()<=(custDetails.getSal()/10)) {
				  return "SELECT";
			  }
			  
		  }
	 
  }
	  return "REJECT";
	}
 
 

	

}
